#include <iostream>
#include <winsock2.h>
#pragma comment(lib, "ws2_32.lib")
#include "SerializableChatMessage.h"

#define MAX_CLIENTS 5

int main()
{
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        std::cerr << "Failed to initialize Winsock." << std::endl;
        return 1;
    }

    SOCKET serverSocket = socket(AF_INET, SOCK_DGRAM, 0);
    if (serverSocket == INVALID_SOCKET) {
        std::cerr << "Failed to create socket." << std::endl;
        WSACleanup();
        return 1;
    }

    sockaddr_in serverAddr;
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(12345);
    serverAddr.sin_addr.s_addr = INADDR_ANY;

    if (bind(serverSocket, reinterpret_cast<sockaddr*>(&serverAddr), sizeof(serverAddr)) == SOCKET_ERROR) {
        std::cerr << "Failed to bind socket." << std::endl;
        closesocket(serverSocket);
        WSACleanup();
        return 1;
    }

    char buffer[1024];

    sockaddr_in clientAddrs[MAX_CLIENTS];
    int clientCount = 0;

    while (true) {
        sockaddr_in clientAddr;
        int clientAddrLen = sizeof(clientAddr);

        int bytesRead = recvfrom(serverSocket, buffer, sizeof(buffer), 0, reinterpret_cast<sockaddr*>(&clientAddr), &clientAddrLen);
        if (bytesRead > 0) {
            buffer[bytesRead] = '\0';
            SerializableChatMessage decoded("", "");
            decoded = decoded.FromString(buffer);
            std::cout << "Received: " << decoded.message << std::endl;

            bool isNewClient = true;
            for (int i = 0; i < clientCount; ++i) {
                if (clientAddrs[i].sin_addr.s_addr == clientAddr.sin_addr.s_addr) {
                    isNewClient = false;
                    break;
                }
            }

            if (isNewClient && clientCount < MAX_CLIENTS) {
                clientAddrs[clientCount++] = clientAddr;
            }

            //broadcast do klientow
            for (int i = 0; i < clientCount; ++i) {
                sendto(serverSocket, buffer, bytesRead, 0, reinterpret_cast<sockaddr*>(&clientAddrs[i]), sizeof(clientAddrs[i]));
                std::cout << "Response has been broadcasted to all connected clients: " << decoded.message << std::endl;
            }
        }
    }

    closesocket(serverSocket);
    WSACleanup();

    return 0;
}
