#pragma once
#include <ctime>
#include <string>

class SerializableChatMessage
{
public:
	std::string message;
	std::string avatar;

	SerializableChatMessage(std::string message, std::string avatar);
	std::string ToString();
	SerializableChatMessage FromString(std::string data);
};